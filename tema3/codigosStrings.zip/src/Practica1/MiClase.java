package Practica1;

public class MiClase{
private int valor = 0;
public MiClase(int param) { 
this.valor = param; }
public void  setValor(int param) { 
this.valor = param; }
public int getValor() { 
return this .valor; }
public String toString() { 
return Integer.toString(valor); }
}

